# Vòm Trời May Áo Cưới (`vom-troi-may-ao-cuoi`)

Botanical luxury wedding invitation template for **Mây Hẹn (`mayhen.vn`)**, cloned and engineered to Mây Hẹn standards from `https://s.27biggroup.com/wedding17-V2`.

## Package Contents
- `template.blade.php` — Canonical 10-section Blade view (`@extends('client.layouts.invitation')`, `1,266` lines, `77` `data-sync-target` bindings across `59` unique keys).
- `styles.css` — 100% pure Vanilla CSS3 scoped under `.mayhen_invitation_root` with BEM `.mayhen_invitation_*` classes, Flexbox/CSS Grid layout, desktop `@media (min-width: 900px)`, and `25` CSS `@keyframes` animations (`3,751` lines).
- `script.js` — Native ES Module handling envelope opening, turntable audio playback, live countdown & Monday-first dynamic calendar, 3D coverflow gallery + lightbox, 3D gift box, pointer/mouse/touch signature canvas, RSVP, and Wishes API submission (`1,101` lines).
- `schema.json` — Mây Hẹn Schema V2 definition covering all `10` canonical sections (`hero`, `story`, `parents`, `countdown_calendar`, `events`, `timeline`, `dresscode`, `album`, `gift`, `ending`).
- `assets/` — `106` 100% self-hosted assets (`9.57 MB`): `21` photography/QR/thumbnail WebPs, `48` botanical watercolor ornament WebPs, `36` local font binaries (`W17 Indulge`, `W17 Fleur`, `Jura`, `Lustria`, `Pattaya`, `Philosopher`), and `1` MP3 track (`wedding-song.mp3`).
- `assets-manifest.json` — SHA-256 checksums, byte sizes, and source attribution for all `106` local assets.
- `reference-audit.md` — Reference DOM/token audit and engineering adaptations.
- `visual-audit.md` — Headless Chromium CDP verification summary (`0px` overflow across `320px–1440px`, `0` broken images, `0` JS/HTTP errors).
- `qa/` — Side-by-side reference captures (`qa/reference/`) and Mây Hẹn rendered captures + JSON telemetry (`qa/local/`).

## Installation Into Mây Hẹn Repository
1. Copy `template.blade.php`, `styles.css`, `script.js`, `schema.json`, and `assets/` into `resources/views/client/invitations/vom-troi-may-ao-cuoi/`.
2. Ensure `vom-troi-may-ao-cuoi` is registered in `database/seeders/InvitationTemplateSeeder.php` and seeded:
   ```bash
   php artisan db:seed --class=InvitationTemplateSeeder
   ```
3. Preview live at `/xem-thu/vom-troi-may-ao-cuoi` and create invitations at `/tao-thiep?template=vom-troi-may-ao-cuoi`.
