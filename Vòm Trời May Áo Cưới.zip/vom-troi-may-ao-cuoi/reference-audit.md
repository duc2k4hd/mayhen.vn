# Reference Audit — Vòm Trời May Áo Cưới (`vom-troi-may-ao-cuoi`)

## 1. Reference Metadata
- **Reference URL**: `https://s.27biggroup.com/wedding17-V2`
- **Page Title**: `Kính mời Quý Khách tới dự tiệc cưới cùng chúng mình`
- **Target Template Identity**: `Vòm Trời May Áo Cưới` (`slug: vom-troi-may-ao-cuoi`, `category: luxury`, `tier: free`)
- **Reference Dimensions (CDP Capture)**:
  - Mobile (`390x844`): `scrollW = 390px`, `scrollH = 13433px`, Opening Curtain (`#w17Mo` + `#w17NutMo`) overlays `390x844` at `z-index: 100`.
  - Desktop (`1440x900`): `scrollW = 1430px`, `scrollH = 13531px`, outer backdrop `rgb(226, 236, 227)` around full-bleed canvas `#ffffff`.
- **Parsed Reference Assets & Source Profile**:
  - Original document HTML size: `1,841,543` bytes (`60` keyframes, `16` raw structural sections, `hasLadi: true`).
  - Extracted 106 local assets (`9.57 MB` total): `21` photography/QR/thumbnail WebPs, `48` botanical watercolor ornament WebPs (`.webp` extracted from CSS custom properties `--a-*`), `36` self-hosted font binaries (`.woff2` + `.otf` + `.ttf`), and `1` background music track (`wedding-song.mp3`).

## 2. Design Tokens & Typography
- **Palette**:
  - Outer Canvas / Backdrop: `#E2ECE3` (`rgb(226, 236, 227)`) -> Sage Card Surface `#FFFFFF`
  - Primary Botanical Sage: `#618768` & Deep Forest Sage `#45664B`
  - Soft Sage Tint / Borders: `#EEF4EE` / `#C9DCCD`
  - Muted Warm Cream / Paper Accents: `#FAF8F4`
- **Typography Stack (100% Self-Hosted, Zero Google Fonts CDN at Runtime)**:
  - Script & Display Flourishes: `W17 Indulge` (`w17-indulge-script.otf`), `W17 Fleur` (`w17-fleur-de-leah.ttf`), `Pattaya`
  - Editorial Headings: `Philosopher`, `Lustria`
  - Body / Numerals / Countdown: `Jura`

## 3. Section-by-Section Mapping & Structural Normalization
| Order | Reference Band | Mây Hẹn Canonical Section (`data-mayhen-section`) | Layout & Adaptation Notes |
|---|---|---|---|
| 1 | Envelope Opening Overlay (`#w17Mo`) | Opening Screen (`#mayhenOpeningCurtain`) | 3D envelope seal reveal + petal fall; bypassed cleanly under `$isEmbed` |
| 2 | Hero + Vinyl Audio + Portraits + Invitation Letter | `hero` (`#mayhen_section_hero`) | Staggered arches, spinning vinyl disc + waveform, swapped portrait URLs so Groom & Bride match photos |
| 3 | Two Families (`NHÀ TRAI` / `NHÀ GÁI`) | `parents` (`#mayhen_section_parents`) | Parent names, address, & Crest SVG via clean Flexbox columns |
| 4 | Save the Date & Calendar | `countdown_calendar` (`#mayhen_section_countdown_calendar`) | Live JS countdown + dynamic Monday-first calendar grid (`window.renderMayhenWeddingCalendar`) |
| 5 | Event Times, Venue & Maps | `events` (`#mayhen_section_events`) | Ceremony timings, Google Maps URL button, Dynamic Google Calendar link |
| 6 | Timeline Schedule | `timeline` (`#mayhen_section_timeline`) | Vertical milestone icons & times synced via `timeline.{i}.*` |
| 7 | Hanging Polaroids & Interactive Signature Wall | `story` (`#mayhen_section_story`) | 4 hanging Polaroid frames + pure canvas HTML5 Signature Board (zero human portrait photos — Luật #8) |
| 8 | 3D Coverflow Photo Album | `album` (`#mayhen_section_album`) | 10 local gallery WebPs with `loading="eager"` + fullscreen Lightbox |
| 9 | Interactive 3D Gift Box & QR | `gift` (`#mayhen_section_gift`) | Lid-fly animation + dynamic `VietQrService::resolveQrImage()` QR generation (hidden when `$isCuratedSeven`) |
| 10 | Dresscode Swatches & RSVP + Thank You Arch | `dresscode` + `ending` (`#mayhen_section_dresscode`, `#mayhen_section_ending`) | 1-row 4-swatch twill weave on mobile + API-connected RSVP/Wishes + Botanical Arch closing (zero human photos in RSVP) |

## 4. Deviations From Reference & Mây Hẹn Engineering Upgrades
1. **Zero Position Absolute Drag-Drop**: Replaced LadiPage fixed pixel offsets with pure Flexbox & CSS Grid (`styles.css`, `3,751` lines) so resizing/live-editing text of any length never overlaps adjacent elements.
2. **Portrait Orientation Fix**: Swapped `bride-portrait.webp` (`134,324B`) and `groom-portrait.webp` (`126,202B`) so visual subjects match the `Chú rể` / `Cô dâu` labels accurately.
3. **Luật #8 Compliance (Signature & RSVP)**: Stripped any background human imagery inside `#mayhen_section_signature` and `#mayhen_section_ending`, retaining pure canvas strokes, sage paper textures, and watercolor flora ornaments.
4. **Live Studio Contract & API Integration**: Added `77` `data-sync-target` attributes (`59` unique keys) and wired RSVP (`rsvp.submit`), Wishes (`invitation.wish.store`), and Signature (`invitation.signature.save`) to Laravel routes with CSRF headers and XSS-safe DOM updates.
