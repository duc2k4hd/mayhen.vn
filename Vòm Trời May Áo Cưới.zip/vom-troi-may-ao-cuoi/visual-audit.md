# Visual & Browser QA Audit — Vòm Trời May Áo Cưới (`vom-troi-may-ao-cuoi`)

## 1. Visual Parity & Section-by-Section Inspection Summary
Headless Chromium CDP captures (`qa/local/`) were visually compared against reference screenshots (`qa/reference/`):
- **Initial Opening Curtain (`mobile-initial.png`)**: Floral sage backdrop `#E2ECE3`–`#618768`, script title `"Wedding Invitation"`, dynamic wedding date, invitation recipient line, and pulse button `"Ấn vào để Xem"` match reference typography and focal framing.
- **After Envelope Open & Hero Reveal (`mobile-after-open.png`, `desktop-top.png`)**: Hero entrance reveal (`.mayhen_invitation_hero_band.mayhen_invitation_visible`), vinyl audio disc widget, calligraphy names, and staggered Groom/Bride portraits render immediately without clipping.
- **Mid-Page Editorial Flow (`mobile-band-02.png` through `mobile-band-16.png`, `desktop-story.png`)**: Letter & Two Families crest, live Countdown & Monday-first Calendar, Venue Maps button, Vertical Timeline, 4 Hanging Polaroids (`gallery-03.webp` verified `301,016B` HTTP 200), Interactive Signature Canvas, 3D Coverflow Album (`10` slides), and 3D Gift Box with VietQR render crisply with `0` broken `<img>` elements.
- **Dresscode & Arched Ending (`mobile-band-17.png`, `mobile-band-18.png`, `desktop-ending.png`)**:
  - Fixed initial Dresscode wrapping by fitting all 4 twill fabric swatches onto a single horizontal row on `390px` mobile.
  - Adjusted bottom ornament clearance (`-28px`) so botanical twigs and the closing quote inside the botanical arch never collide.

## 2. Headless Chromium CDP Automated Verification (`qa/local/verify-report.json`)
- **Preview URL Tested**: `http://127.0.0.1:8000/xem-thu/vom-troi-may-ao-cuoi` (`totalMobileHeight: 13622px`)
- **Multi-Viewport Overflow Check**:
  - `320x720`: `overflowPx = 0` (`scrollWidth = 320`)
  - `375x812`: `overflowPx = 0` (`scrollWidth = 375`)
  - `390x844`: `overflowPx = 0` (`scrollWidth = 390`)
  - `430x932`: `overflowPx = 0` (`scrollWidth = 430`)
  - `480x900`: `overflowPx = 0` (`scrollWidth = 480`)
  - `1440x900`: `overflowPx = 0` (`scrollWidth = 1440`)
- **Studio Embed & Live Sync (`?embed=1&mode=editor`)**:
  - Opening curtain hidden (`display: "none"`), Hero card visible (`opacity: "1"`), Gift panel accessible (`display: "block"`), `overflowEmbed: 0`.
  - Dispatched `MAYHEN_SYNC_INPUT` messages updated `[data-sync-target="groom_name"]` -> `"Hoàng Duy"`, `[data-sync-target="wedding_month"]` -> `"05"`, and `[#mayhenDresscodeSwatches]` -> `3` swatches live.
- **Interactive Flows Verified**:
  - Envelope open click (`openResult.clicked: true`), Hero `object-fit: cover`, `bodyScrollLockedAfterOpen: false`.
  - Signature Canvas stroke draw & save (`sigHitId: "mayhenSignatureCanvas"`, `sigCardCount: 1`).
  - 3D Coverflow navigation (`cfMovedTo: "7"`) + Lightbox open (`lightboxOpened: true`).
  - 3D Gift Box unlock animation (`giftBtnClicked: true`, `giftUnlockedAfter: true`).
  - Create route `GET /tao-thiep?template=vom-troi-may-ao-cuoi`: `HTTP 200`, title `Đang chọn mẫu: "Vòm Trời May Áo Cưới" | Mây Hẹn`, `hasFatalError: false`.
- **Zero-Error Totals**:
  - `totalImgs: 23`, `brokenImgs: []`
  - `localHttpErrors: []`
  - `jsExceptions: []`
  - `loadedFontsCount: 14`

## 3. QA Artifacts Included
- `qa/reference/`: `desktop-top.png`, `desktop-fullpage.png`, `mobile-initial.png`, `mobile-after-open.png`, `mobile-fullpage.png`, and `mobile-band-00..18.png` (`24` files).
- `qa/local/`: `desktop-top.png`, `desktop-story.png`, `desktop-ending.png`, `embed-studio.png`, `mobile-initial.png`, `mobile-after-open.png`, `mobile-band-01..18.png`, and `verify-report.json` (`25` files).
