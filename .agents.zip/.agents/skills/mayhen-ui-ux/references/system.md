# Nhiều màn hình — luật D

Mở file này khi đề bài **nhiều hơn một bề mặt**, hoặc đề đòi dựng design system trước
(`D9`). Riêng `D10` (`DESIGN.md`) áp cho mọi đề. Một câu như *"dựng kanban board
quản lý công việc và table quản lý project, có đủ CRUD"* không phải hai màn, mà
là khoảng **tám bề mặt**: board, thẻ, cột rỗng, bảng, dòng bảng, form tạo, form
sửa, hộp xác nhận xoá, bộ lọc.

**Chẩn đoán gốc:** design system quy định màu và cỡ chữ. Nó **không** quy định
rằng thẻ kanban và dòng bảng phải nói cùng một ngôn ngữ. Từng màn đều hợp lệ,
ghép lại thành hai app khác nhau.

Phàn nàn thật từ một người dùng: *có config design system sẵn mà output vẫn không
đồng bộ giữa các màn · không đẹp, AI cứ chọn màu xám tối · phải prompt chỉnh
nhiều lần.*

---

## D1. Định nghĩa hợp đồng nguyên tố TRƯỚC, một lần, cho cả bộ

Trước khi dựng màn đầu tiên, khai ra bảy nguyên tố dưới đây. Mọi màn sau dùng
đúng bộ đó. **Cấm đẻ biến thể giữa chừng.**

| Nguyên tố | Phải chốt |
| --- | --- |
| Nút | bốn dạng ở `I1`, cỡ, có icon hay không |
| Badge trạng thái | hình dạng, nền hay chỉ chữ màu, cỡ chữ |
| Ô nhập | chiều cao, viền, hành vi lúc focus |
| Card | padding, bo góc, có viền hay không |
| Dòng danh sách | chiều cao, padding, hành vi hover |
| Modal | bề rộng, chỗ đặt nút, có cho bấm ra ngoài không |
| Trạng thái rỗng | icon, tiêu đề, câu phụ, có nút không |

Viết bảy dòng này ra **trong lượt trả lời**, trước khi viết HTML. Nó dài chưa tới
mười lăm dòng và nó cứu cả đợt dựng.

Project đã có thư viện component thì bảng này chính là **danh sách component
phải đi tìm**, không phải danh sách phải viết. Xem `S9`.

---

## D2. Một bảng ánh xạ trạng thái duy nhất

`todo` / `doing` / `done`, mức ưu tiên, vai trò — khai **một chỗ** thành cặp
*nhãn + màu*, dùng y hệt ở mọi bề mặt.

Cấm board dùng badge nền màu còn bảng dùng chấm tròn. Cùng một trạng thái mà hai
hình dạng thì người dùng phải học hai lần.

```
STATUS = {
  todo:   { nhãn: "Cần làm",   màu: xám,      icon: "circle" },
  doing:  { nhãn: "Đang làm",  màu: xám,      icon: "circle-dot" },
  review: { nhãn: "Chờ duyệt", màu: hổ phách, icon: "circle-ellipsis" },
  done:   { nhãn: "Xong",      màu: xanh lá,  icon: "circle-check" },
}
```

Màu vẫn theo `M4`: đây là trạng thái thật, nên được dùng màu. Bốn tông và hình
badge lấy đúng bảng trong `M7`; "Đang làm" xám chứ không hổ phách, vì hổ phách là
"cần chú ý" và xanh để dành cho "xong". Hai trạng
thái cùng tông thì tách bằng icon, bảng icon cũng ở `M7`.

**Trạng thái làm tiêu đề thì cùng một hình ở mọi view.** Hàng nhóm của bảng và đầu
cột kanban là **icon + tên + số đếm**, không pill; trạng thái làm giá trị một ô thì
mới là pill. Bảng nhóm dùng pill còn kanban chỉ chữ trơn là cùng một trạng thái hai
hình.

---

## D3. CRUD dùng một bộ khuôn

- **Tạo và sửa dùng CÙNG một form.** Chỉ khác tiêu đề và chữ trên nút. Hai form
  riêng là hai chỗ để lệch nhau.
- **Xoá mà khôi phục được** (thùng rác, xoá mềm) thì **xoá ngay + toast "Hoàn tác"**, như
  Các app lớn: hộp xác nhận cho mọi thùng rác dạy người ta bấm "Đồng ý" không
  đọc. **Hộp xác nhận** chỉ khi không lấy lại được, hoặc xoá nhiều dòng một lúc. Khôi
  phục được hay không là logic, người dùng quyết (`N10`); đề không nói thì hỏi một dòng
  lúc giao. Xem `layouts/overlay.md`.
- Hộp xác nhận bắt **gõ lại một cụm từ** chỉ dựng khi đề yêu cầu (quyết định sản
  phẩm, không phải mặc định), **trừ việc xoá cả không gian** (workspace, tổ chức): việc đó
  mất dữ liệu của mọi thành viên, nên mặc định bắt gõ lại tên, nút xoá mở khoá khi khớp.
  Các sản phẩm lớn đều thêm một bước ngoài hộp hỏi thường cho việc này (gõ
  tên là cách hay gặp nhất; có nơi gửi mã qua email hoặc hỏi mật khẩu). Khi có ô gõ đó thì
  không cho bấm ra ngoài để đóng (`I20`). Khuôn hộp và ô ở `layouts/overlay.md`.

---

## D4. Nhiều màn thì báo bố cục MỘT LẦN cho cả bộ

Đề nhiều màn vào nhánh `U` như mọi đề dựng (`SKILL.md` câu 1): `U2` mỗi màn một dòng,
wireframe cho cả bộ, rồi hợp đồng nguyên tố `D1` chốt ở `U4` trước khi dựng màn đầu tiên.
Bố cục mặc định của từng loại màn chỉ dùng thẳng ở lối "dựng luôn" hoặc việc nhỏ hơn một
màn. Lúc giao báo **một** đoạn: liệt kê các bề mặt đã dựng, màn chính theo phương án nào,
bề mặt phụ (form, hộp xác nhận, trạng thái rỗng) theo khuôn chung nào. Muốn đổi thì người
dùng nói.

---

## D5. Màu nhấn phải thật sự xuất hiện

Liệt kê ra nó được dùng ở đâu. Cả bộ màn không có chỗ nào dùng màu nhấn thì đó
là **chưa quyết định**, không phải tối giản.

Khác biệt nằm đúng ở đây: xám tối **có chủ ý** thì màu nhấn vẫn xuất hiện ở nút
chính, ở trạng thái đang chọn, ở link. Xám tối **vì chưa quyết định** thì cả
trang không có chỗ nào dùng màu nhấn, và nó đọc ra là một bản nháp.

`M2` nói 5% điểm nhấn. **5% không phải 0%.**

---

## D6. Đặt tên khu vực rồi dùng đúng tên đó suốt

Hệ thống nhiều màn luôn có một khung chung: cột trái, vùng nội dung, cột phải,
thanh trên mobile, thanh dưới mobile. Đặt tên một lần, ghi ra, rồi dùng đúng tên
đó trong mọi câu trả lời sau.

Nghe như chuyện nhỏ, nhưng ở một dự án thật đây là mục **đầu tiên** của `AGENTS.md`,
vì không có nó thì mỗi lượt lại phải mô tả lại "cái cột bên trái ấy" và mỗi lần
mô tả lại lệch một chút.

Kèm theo tên thì ghi luôn **code chết**: component nào không được import ở đâu
nữa, để lượt sau không hồi sinh nó.

---

## D7. Khung chung thì sửa sau cùng, hoặc không sửa

Thứ tự đụng vào, từ ít liên đới nhất tới nhiều nhất:

1. Khối đã tự gom theo feature
2. Trang có ít selector
3. Trang lớn
4. Thứ dùng chung khắp nơi — shell, sidebar, modal

Xem `refactor.md` luật `L8` để biết cách đếm quy mô trước khi chọn.

---

## D8. Nội dung lặp lại ở nhiều màn phải có một component

Dấu hiệu: cùng một "thẻ khoá học" xuất hiện ở trang danh sách, trang tìm kiếm,
và cột phải. Ba chỗ đó mà ba lần viết thì chắc chắn ba lần lệch.

Tách thành một component nhận prop, rồi mỗi chỗ chỉ đổi kích thước qua
`className`. Cỡ chữ tên thẻ phải **giống nhau ở mọi breakpoint và mọi chỗ đặt** —
xem `T8`, vì tiêu đề khối được tính theo nó.

---

## D9. Đề "dựng design system trước": nền trước, màn sau ⚑

Đề nói **"design system"**, "dựng component trước", "UI kit", "chốt token, spacing,
typography rồi mới dựng màn", "build a design system", "component library first" thì vào
đây (`SKILL.md` câu 1), **không vào nhánh `U`**: design system không có bố cục để vẽ
wireframe, thứ cần duyệt là hình của từng nguyên tố. Hợp đồng `D1` ở lối này không còn là
bảy dòng chữ trong lượt trả lời, mà thành code thật và một trang xem được.

1. **Audit câu 2 như mọi lối.** Dự án đã có token hay thư viện component (shadcn, MUI, bộ
   nội bộ) thì design system là **xếp lại cái đang có**: token của họ vào hai vai viền
   `M14`, component của họ chỉnh token cho khớp (`S9`). Không dựng bộ thứ hai cạnh bộ cũ.
   Với shadcn: **giữ tên token của shadcn, trỏ giá trị về token của skill**, để component shadcn
   thêm sau vẫn đúng màu. Tên trùng mà khác nghĩa thì theo shadcn: `--muted` của shadcn là
   *nền*, nên chữ phụ của skill (`text-muted`) viết thành `text-muted-foreground` trong cả dự
   án.
2. **Brief một khối, không dừng**: sản phẩm, người dùng, màu nhấn, font, phong cách (`P1`),
   chỉ sáng hay có tối (`M20`), ngôn ngữ của copy (`T24`). Đề không nói thì lấy mặc định
   của `brand-tokens.md` (gần đen, Inter, flat, chỉ sáng) và ghi vào brief. Dự án chưa có
   màu brand thì trang design system có nhóm ba màu gợi ý theo ngành (`brand-tokens.md`), như
   nhóm Nhấn trên thanh wireframe (`wireframe.md`, `U3`).
3. **Token**: chép `tokens.css` vào file token của dự án theo `brand-tokens.md`, chỉ sửa
   khối font và màu nhấn. Thang cỡ chữ, nhịp, chiều cao control lấy từ `budgets.md`; bo
   góc theo `F1`, `M19`. **Không đẻ thang hay token mới** (`M14`, `M16`): bộ của skill đã
   qua test, nghĩ lại từ đầu là mất phần đó.
4. **Component: bảy nguyên tố của `D1`** (nút, badge trạng thái, ô nhập, card, dòng danh
   sách, modal, trạng thái rỗng), **cộng những gì đề nêu tên**. Mỗi cái chép công thức từ
   file mẫu của nó (bảng "Mở khi dựng đúng khối đó", mục 2 của `SKILL.md`), đặt theo quy
   ước thư mục của dự án. Không dựng hết các mẫu cho "đủ bộ" (`S1`); lúc giao liệt kê
   những mẫu còn sẵn, cần cái nào thì gọi tên.
5. **Một trang xem design system**: route `/design-system` (dự án có Storybook thì viết
   story thay cho trang; không có app thì một file HTML). Dự án có dark mode thì trang có
   nút đổi theme ở đầu trang (`M31`) để duyệt cả hai bản, và bảng màu ghi mã cả hai theme.
   Thứ tự khối:
   - **Màu**: ô màu kèm tên token và mã; cặp chữ trên nền chính kèm tỉ lệ tương phản. Cột
     tỉ lệ chỉ ghi số; **chỉ cặp trượt mới có nhãn** ("Dưới 4.5:1", màu cảnh báo), cặp đạt
     để trống. Mười một dòng "Đạt AA" xanh giống nhau là một ý nói mười một lần, mắt phải dò
     hết cột mới biết có cặp nào trượt không.
   - **Chữ**: từng bậc của thang cỡ chữ, viết bằng câu thật theo ngôn ngữ của dự án (tiếng
     Việt thì có đủ dấu, `T5`), ghi cỡ và độ đậm.
   - **Khoảng cách, bo góc, viền, bóng**: các bậc đang dùng, hai vai viền đặt cạnh nhau,
     bóng của lớp nổi.
   - **Từng component**, mỗi trạng thái một ví dụ tĩnh đặt cạnh nhau (thường, rê, focus,
     khoá, đang tải, lỗi), không bắt bấm mới thấy. Trang dùng **chính component vừa
     dựng**, không vẽ lại cho đẹp: trang đẹp mà component lệch thì duyệt nhầm.
     **Nhãn trạng thái ("Thường", "Rê", "Đang gõ", "Lỗi", "Khoá") nằm cùng một chỗ ở mọi
     khối**: chữ nhỏ `text-xs text-muted` ngay trên ví dụ. Không đặt nhãn vào chỗ câu gợi ý
     hay câu lỗi dưới ô nhập: "Đang gõ" nằm dưới ô trông y như câu gợi ý thật của ô đó. Ô
     nhập bày cạnh nhau thì cách nhau như trong form thật (`gap-y-5` trở lên), không `gap-y-2`:
     câu gợi ý của ô trên chỉ cách nhãn ô dưới 10px, đọc ra là nhãn của ô dưới.

   **Ví dụ ép trạng thái** (nút tô sẵn nền rê, ô vẽ sẵn viền focus, select và modal mở sẵn trong
   khung tĩnh, nút nhãn dài trong khung hẹp) bọc trong `<div inert data-demo-state="hover">` (giá
   trị là tên trạng thái). `inert`: Tab không dừng ở ô giả focus, rê vào không đổi gì. Probe bỏ
   qua các khối này ở phép đo rê, lớp nổi, viền trang trí, nút xuống dòng; không bọc thì mỗi
   ví dụ thành một mục Hỏng giả. Ví dụ "Thường" thì **không** bọc,
   đó là component thật để probe đo.

   Trang là công cụ để duyệt: flat như gu skill, không hero, không lời quảng cáo.
6. **Probe trang đó** (`--sweep`) tới khi danh sách `P` trống, tối đa ba vòng.
7. **Cổng duy nhất của lối này**: gửi link, kèm một dòng *"Duyệt thì trả lời `ok`. Muốn đổi
   màu nhấn, font, bo góc thì nói: đổi ở token, mọi component đổi theo."* Dừng chờ.

Duyệt xong thì ghi màu nhấn đang hiện trên trang (màu người dùng chọn trong nhóm gợi ý, không
chọn thì màu đầu) vào file token trước khi làm màn, và ghi `DESIGN.md` (`D10`). Màn sau đi lối bình thường (mặc định nhánh
`U`): wireframe `U3` dán file token của dự án, chép class từ component vừa duyệt, không hiện
nhóm Nhấn; `U4` ráp từ đúng các component đó; bảng `D1` coi như đã chốt, không khai lại. Đề vừa đòi design system vừa
đòi màn ("dựng design system rồi dựng màn đơn hàng") thì làm hết lối này, qua cổng, rồi mới
vào `U1` cho màn.

## D10. `DESIGN.md`: quyết định giao diện nằm một chỗ trong dự án ⚑

Mỗi phiên mới, model không nhớ phiên trước đã chọn gì. Bộ mặt, màu nhấn, phong cách, bố cục
đã duyệt chỉ nằm rải trong code (một dòng comment trong file token, class trên vài component),
nên phiên sau audit ra khác, khuyên lại từ đầu, và màn thứ năm lệch màn đầu (chủ dự án:
ba màn hai mặt). `DESIGN.md` ở gốc dự án là trí nhớ đó.

**Đọc** ở audit câu 2 của `SKILL.md`, mọi lối, kể cả việc nhỏ hơn một màn. Có file thì những gì
nó ghi **thắng** mặc định và lời khuyên của skill (bộ mặt `P13`, màu nhấn theo ngành, bố cục mặc
định): người dùng đã chọn rồi, không khuyên lại, không hỏi lại. Dòng `Audit:` nói một đoạn:
*"`DESIGN.md`: bộ mặt Soft, nhấn Tím."* File ghi trái với code đang chạy (file nói Soft, code
toàn flat Inter) thì code là thật, file sai: theo code, sửa file, báo một dòng lúc giao.

**Ghi** mỗi khi skill chốt một quyết định cho cả dự án, sau khi người dùng đã duyệt (không ghi
lúc còn ở wireframe, `U3`):

- `U4` dựng xong màn đầu tiên; lối dựng luôn dựng xong; `D9` qua cổng; hai chế độ dựng lại của
  `review.md` dựng xong.
- Người dùng dặn một điều cho cả app ("nút bo tròn hết", "đừng dùng màu tím", "bảng luôn dày"):
  ghi vào mục Người dùng dặn, kể cả khi điều đó đè luật skill.
- Màn mới dựng xong: thêm một dòng vào mục Màn đã dựng.
- Luồng nhiều màn dựng xong: ghi sơ đồ luồng màn (`flows.md`, `O7`) vào mục Luồng, gồm dòng
  đường chính và bảng. Mục này không tính vào giới hạn ~40 dòng: người phát triển đọc nó khi
  nối logic.

Sửa tại chỗ, không chép thêm lịch sử: file là trạng thái hiện tại, lịch sử đã có git. Lúc giao
nói một dòng *"Đã ghi vào `DESIGN.md`: …"*.

**Mẫu**, giữ dưới ~40 dòng, chỉ ghi điều đã chốt:

```markdown
# Thiết kế giao diện

Skill evon:ui-ux đọc file này trước khi dựng. Sửa tay được; file trái với code thì code thắng.

## Sản phẩm
- Sản phẩm: app học tiếng Anh cho người đi làm
- Người dùng: nhân viên văn phòng, học 15 phút giờ nghỉ trưa
- Việc chính: học tiếp bài đang dở, ôn từ, xem tiến độ
- Nền tảng: điện thoại nhiều hơn máy tính
- Điểm khác biệt: bài học theo ngành nghề của người học

## Giao diện
- Bộ mặt: Soft (P13): điều hướng sidebar, vùng chứa classic, header content, bề mặt nổi (P7), font Be Vietnam Pro
- Sắc: Tinted (P17): Bài học cat-1, Ôn từ cat-2, Kiểm tra cat-3 (một loại một sắc trên mọi màn)
- Màu nhấn: Tím `#7c3aed`, token `--primary` ở `app/globals.css`
- Phong cách: nổi (P7), không glass, không gradient
- Nền tối: có, theo `class="dark"`

## Người dùng dặn
- Nút bo tròn hết (đè luật bo góc của skill)

## Màn đã dựng
- `/` Trang đầu người học: phương án B, card Học tiếp đứng đầu
- `/courses` Danh sách khoá: phương án A, lọc dính đầu trang

## Luồng
Onboarding: Đăng ký → Chọn ngành → Bài đầu tiên → Kết quả bài. 3 màn, 2 ô.
| # | Từ màn | Người dùng làm gì | Tới | Loại |
| --- | --- | --- | --- | --- |
| 1 | Đăng ký `/signup` | Bấm "Tạo tài khoản" | Chọn ngành `/onboarding` | Chính |
| 2 | Chọn ngành `/onboarding` | Bấm "Bỏ qua" | Bài đầu tiên, ngành chung | Bỏ qua |
```

**Không ghi:** tên sản phẩm đã tra để tham khảo, số liệu giả, lý do dài, luật skill đã có
sẵn (file không phải bản sao của skill). Dự án đã có `DESIGN.md` không do skill viết (không có
dòng "Skill evon:ui-ux đọc file này") thì đọc như tài liệu của người dùng, không viết đè: thêm
các mục trên vào cuối, dưới tiêu đề `## evon:ui-ux`.
