# Biểu đồ và số liệu

Biểu đồ là chỗ luật một màu nhấn hay bị phá nhất. Bốn ô số liệu bốn màu, cột
xanh cột đỏ, biểu đồ tròn bảy múi bảy sắc. Nhìn thì tưởng nhiều thông tin, thật
ra là không quyết định được cái nào quan trọng.

File này viết cho màn có chuột. **Biểu đồ trong app điện thoại** (chạm thay rê, hàng đọc số, trục co theo dữ liệu
giá, cột đang chọn, nhãn ở khổ hẹp, màu danh mục) đọc thêm `J17` trong `../mobile/charts.md`; chỗ nào hai bên khác nhau
thì `J17` thắng.

---

## Màu

**Một chuỗi dữ liệu là một màu.** Tám cột của cùng một chỉ số thì cả tám cùng
`--chart-fill` (bản sáng chính là `--primary`, bản tối hạ còn 70%, xem "Nền tối" dưới). Cột cao thấp đã nói lên khác biệt rồi, không cần màu nói lại.

**Hai tới bốn chuỗi thì phân biệt bằng đậm nhạt, không bằng sắc** (dự án chưa có thang màu biểu đồ). Đổi hue là bắt
người đọc học một bảng chú giải màu mà họ không xin. Một thang cho cả app, biểu
đồ cột nhóm và phần donut dùng chung (`N5`):

| Số chuỗi / phần | Bậc |
| --- | --- |
| 2 | `bg-chart-fill` · `bg-chart-fill/45` |
| 3 | `bg-chart-fill` · `bg-chart-fill/45` · `bg-chart-fill/15` |
| 4 | `bg-chart-fill` · `bg-chart-fill/65` · `bg-chart-fill/35` · `bg-chart-fill/15` |

Không dùng `--muted` làm một bậc: nó gần bằng `primary/60`, hai chuỗi trông như
một. Bậc `/15` và `/35` dưới 3:1 trên nền
trắng, nên **mỗi cột, mỗi phần phải có con số đi kèm** (số trên đầu cột, số
trong bảng chú giải donut); màu nhạt không bao giờ là thứ duy nhất mang giá trị
(`N4`). Chấm chú giải dùng đúng class của cột.

**Thanh chia theo các bước của một quy trình** (chờ xác nhận → đang làm → xong, kèm huỷ): bước mang nghĩa trạng
thái giữ màu trạng thái (chờ `--warning`, xong `--success`, huỷ `--danger`, `M7`); các bước đang làm dở ở giữa
là đậm nhạt của `--chart-fill` theo thứ tự, bước sau đậm hơn (bảng bậc ở trên). Không tô các bước giữa bằng xám:
xám đọc thành "chưa tô" hay "không hoạt động", thanh trông như làm dở. Chấm cạnh tên bước trong danh sách dưới
thanh dùng đúng màu của đoạn đó.

**Phân loại từ 5 nhóm trở lên thì mỗi nhóm một sắc.** Ngành, kênh, quốc gia, loại
khách: năm bậc đậm nhạt của một màu thì bậc 4 và bậc 5 mắt không tách được nữa, chấm
màu trong bảng không còn chỉ về đúng thanh nào. Các app phân tích phổ biến đều tô mỗi
nhóm một sắc ở đây (thanh chia phần, donut, cột chồng). Cách làm:

- **Dự án có thang màu biểu đồ** (`--chart-1`…`--chart-5` của shadcn, thang riêng, hay khối Sắc
  `--cat-1`…`--cat-6` của `P17`) thì dùng đúng thang đó theo thứ tự. Dự án đã chọn Sắc Tinted, Vivid
  thì thang `--cat-*` dùng cả khi dưới 5 nhóm. Dự án có ngôn ngữ màu riêng (`P4`) thì thang theo dự
  án kể cả khi dưới 5 nhóm.
- **Chưa có** thì dùng thang mặc định, xếp theo thứ tự nhóm lớn tới nhỏ: `blue-500` ·
  `sky-400` · `violet-500` · `fuchsia-400` · `teal-500` · `indigo-300`. Tránh sắc trùng
  bảng trạng thái (`red`, `rose`, `amber`, `emerald`) khi cùng màn có badge trạng thái,
  để một nhóm không bị đọc thành "lỗi" hay "xong".
- **Tối đa 6 sắc**, nhóm thứ 7 trở đi gộp thành "Khác" màu `slate-300`. Bảy tám sắc
  thì lại thành cầu vồng không ai nhớ.
- **Một nhóm một màu cố định trong cả app** (như `M8`): "Media" tím ở thanh chia phần
  thì tím ở donut, ở chấm trong bảng.
- **Chấm màu trong bảng dùng đúng màu của thanh**, và mỗi nhóm luôn có số và phần trăm
  bằng chữ: màu chỉ giúp nối bảng với biểu đồ, không mang giá trị (`N4`).

**Màu chỉ được đổi sắc khi nó mang nghĩa trạng thái** (ngoài ca phân loại từ 5 nhóm ở trên), và phải trùng đúng bảng
trạng thái của app: đỏ là hỏng hoặc thất bại, amber là quá hạn hoặc cần chú ý,
emerald là xong. Cột "quá hạn" tô amber thì được (`M7`, `list-row.md`). Cột "tháng 3" tô đỏ thì không.

**Ô số liệu thì con số để nguyên màu chữ chính** (Sắc Tinted, Vivid cho phép tô một số đang ở mức báo động, `P17`). Đừng tô "Đang làm" xanh,
"Quá hạn" đỏ, "Hoàn thành" xanh lá. Bốn màu trong một hàng là dấu hiệu chưa
chọn được cái nào đáng nhìn nhất. Cần nhấn một ô thì nhấn bằng vị trí hoặc bằng
dòng phụ, không bằng màu.

**Nền tối** (`M32`). **Mảng dữ liệu là `--chart-fill`, không `--primary` trần.** Nền tối màu
nhấn gần trắng, cột 100% là khối chói nhất màn, nặng hơn cả tên trang (chủ dự án chọn 70%;
đừng dùng xám ánh xanh: nhạt quá, lẫn với cột kỳ đang chạy). Khối `.dark` của `tokens.css` đã hạ token này
còn 70%, thang `/45`, `/15` nhân theo nên giữ đúng tỉ lệ. Thanh mảnh (thanh tiến độ, `h-2`)
vẫn `bg-primary`: diện tích nhỏ, không chói. Lưới `stroke-border` và nhãn `text-muted` tự đổi
theo theme. Phải khai riêng:

- **Thang phân loại** viết bằng class sắc thì thêm bản tối, sáng lên một bậc:
  `blue-500 dark:blue-400` · `sky-400` giữ · `violet-500 dark:violet-400` · `fuchsia-400` giữ ·
  `teal-500 dark:teal-400` · `indigo-300` giữ. Nhóm "Khác" `slate-300` thành **`dark:slate-600`**:
  để nguyên thì xám sáng thành mảng nổi nhất biểu đồ tối.
- **Thư viện vẽ bằng mã màu** (Recharts `fill="#…"`, Chart.js) thì truyền `var(--…)` hoặc đọc
  token lúc vẽ, không viết hex: hex cứng không lật theo theme. shadcn chart: `ChartConfig` nhận
  `theme: { light, dark }`, hoặc `--chart-1…5` có bản `.dark`.

---

## Bỏ bớt đi

- **Không lưới, không trục Y** ở biểu đồ trong card dashboard, panel, ô số liệu. Ghi thẳng con số lên đầu cột hoặc cuối dòng. Người ta muốn biết giá trị, không muốn dóng mắt sang trục.
  **Ngoại lệ: biểu đồ chính của trang báo cáo** (biểu đồ là thứ người ta vào trang để đọc, rộng hết khung, từ ~15 mốc). Ở đó người ta so ngày này với ngày kia ("13/09 khoảng 70 tr, 22/09 khoảng 40 tr") mà không muốn rê 30 lần. Thêm **3–4 đường lưới ngang** mảnh (`stroke-border`, 1px, không nét đứt) ở các mức số tròn (0, 20 tr, 40 tr, 60 tr), nhãn mức `text-xs text-muted tabular-nums` ở mép trái, không đường trục dọc, không lưới dọc. Bộ component dashboard phổ biến nhất bật lưới ngang và bỏ nhãn trục Y; một thư viện dashboard lớn và trang báo cáo của một nền tảng bán hàng lớn bật cả hai. Cả ba nguồn đều có lưới ngang, nên lưới ngang là số đông; nhãn mức hai trên ba, giữ vì trang báo cáo là để đọc số. Recharts: `<CartesianGrid vertical={false} stroke="var(--border)" />` + `<YAxis axisLine={false} tickLine={false} tickCount={4} width={48} tick={{ fill: "var(--muted)", fontSize: 12 }} />`.
- **Không chú giải rời** khi có thể ghi nhãn ngay cạnh dữ liệu.
- **Không biểu đồ tròn cho quá bốn phần.** Quá bốn thì mắt không so được, chuyển sang thanh ngang xếp theo thứ tự lớn dần.
- **Không hiệu ứng lúc vào trang.** Cột không mọc lên, đường không tự vẽ, số không đếm tăng dần. Xem luật `F23` trong `../rules-form.md`.
- **Không đổ bóng, không gradient, không 3D** cho cột và mảng.

---

## Vẽ bằng thư viện, skill lo hình

Biểu đồ đường, cột, donut ở dự án thật hầu như luôn vẽ bằng thư viện: nó lo tỉ
lệ trục, co giãn theo khung, rê chuột, bàn phím. Nên (`N10`, bảng thư viện
chuyên dụng trong `SKILL.md`):

1. **Dự án đã có** thư viện biểu đồ (Recharts, shadcn chart, Chart.js, ECharts,
   Tremor…) thì **dùng đúng cái đó**, cấu hình theo bảng dưới. Audit grep
   `package.json` trước khi viết một dòng.
2. **Chưa có thì không tự cài.** Dựng như bình thường theo các mẫu ở mục "Công
   thức dùng được ngay". Hình của skill đã bỏ gần hết thứ thư viện bán (lưới,
   trục Y, tooltip, chú giải, hiệu ứng), nên vài biểu đồ tĩnh trên một trang
   dashboard thường **không cần thư viện nào**: `<svg>` và div là đủ, nhẹ nhất.
3. **Chỉ đề xuất thư viện khi có nhu cầu mà tự dựng sẽ tốn**, và lúc giao nói
   rõ nhu cầu đó: nhiều loại biểu đồ khắp app, dữ liệu hàng nghìn điểm, phóng to
   hay kéo chọn vùng, cập nhật theo thời gian thực, trục thời gian có khoảng
   trống. Không có nhu cầu nào như vậy thì không đề xuất.
4. **Chọn thư viện theo tiêu chí, không theo tên quen**: nhẹ (xem kích thước
   thật trên bundlephobia lúc đề xuất, đừng nhớ số), làm được đúng các loại
   biểu đồ đang cần, tô được bằng token CSS, còn được bảo trì, chạy được với
   SSR nếu dự án có. Hợp với hệ sinh thái sẵn có cũng là một tiêu chí: dự án
   dùng shadcn thì shadcn chart nhất quán với phần còn lại, dù Recharts bên dưới
   không phải thư viện nhẹ. Đề xuất ghi một dòng, có lý do: "Nếu sau này cần
   phóng to biểu đồ 10.000 điểm, cân nhắc X vì Y".

Thanh tiến độ, thanh ngang trong danh sách thì luôn dựng bằng div, kể cả khi
có thư viện: chúng chỉ là một thanh có `width`. **Sparkline** cũng không cần thư
viện: một `<svg>` với `<polyline>`, không trục, không rê chuột, không cần đề
xuất thư viện chỉ vì nó. Dự án đã có Recharts thì dùng `<LineChart>` trơn cũng
được, nhưng bốn `ResponsiveContainer` trong một hàng là nặng hơn cần thiết.

**Skill chỉ quy định hình.** Mọi thư viện bật sẵn thứ skill cấm, phải tắt tay.
Ví dụ với Recharts / shadcn chart (vì hay gặp nhất, không phải vì được chọn):

| Luật hình | Cấu hình |
| --- | --- |
| Không lưới | bỏ `<CartesianGrid>` (biểu đồ chính trang báo cáo: lưới ngang, xem "Bỏ bớt đi") |
| Không trục Y | `<YAxis hide domain={[0, "auto"]} />` (đáy luôn 0; trang báo cáo: hiện nhãn mức) |
| Trục X chỉ nhãn, đáy một đường mảnh | `<XAxis tickLine={false} axisLine={{ stroke: "var(--border)" }} tick={{ fill: "var(--muted)", fontSize: 12 }} />` |
| Không hiệu ứng vào trang (`F23`) | `isAnimationActive={false}` trên mọi `<Line>`, `<Bar>`, `<Pie>` |
| Số ghi trên đầu cột | `<LabelList position="top" />`, cùng màu `--muted`, `text-xs` |
| Đường: chỉ chấm và số ở điểm cuối (hoặc điểm đang rê) | `dot={false}`, `activeDot` tắt, tự vẽ chấm + nhãn bằng `<ReferenceDot>` hoặc `label` theo chỉ số điểm đang chọn |
| Không tooltip nổi cho đường | bỏ `<Tooltip>`, đọc điểm đang rê qua `onMouseMove` để dời chấm và số (bản dựng thử giữ `<Tooltip content={() => null} cursor={false} />` để Recharts tính `activeTooltipIndex` mà không vẽ hộp, không vạch dọc) |
| Nhãn trục X đầu, cuối không lòi mép | `tick` tự vẽ: nhãn đầu `textAnchor="start"`, nhãn cuối `"end"`, còn lại `"middle"`. Mặc định `middle` cắt nửa chữ "09:20", "Bây giờ" ở hai mép (bản dựng thử) |
| Đường ngưỡng (màn giám sát) | `<ReferenceLine y={150} stroke="rgb(239 68 68 / 0.6)" strokeDasharray="5 4" label={{ value: "Ngưỡng 150 ms", position: "insideTopLeft", dy: -18, fill: "var(--muted)", fontSize: 12 }} />`. Số của điểm đang xem nằm **dưới** chấm khi điểm dưới ngưỡng: đặt trên thì ở 375px nó đè lên nhãn ngưỡng (bản dựng thử) |
| Cột bo góc | `radius={[8, 8, 0, 0]}` (cột nhóm hẹp: `[6, 6, 0, 0]`) |
| Màu từ token, đúng thang đậm nhạt | `fill="var(--chart-fill)"` + `fillOpacity` theo bảng ở mục Màu, không để bảng màu mặc định của thư viện |
| Donut | `<Pie innerRadius="72%" startAngle={90} endAngle={-270} paddingAngle={1} stroke="var(--surface)">`, dữ liệu đã xếp lớn dần |
| Chưa có số (khác 0) | giá trị `null` + `connectNulls={false}` để đường đứt |
| Chú giải | bỏ `<Legend>` của thư viện, dựng chú giải bằng HTML theo spec (chấm cùng class cột) |

Thư viện khác thì tìm đúng các tuỳ chọn tương ứng; hình cuối cùng phải y như
bảng trên. Các mẫu HTML bên dưới là **hình cần đạt**: có thư viện thì để so,
chưa có thư viện thì dựng theo đúng mẫu đó.

## Cột hay đường

| Dữ liệu | Loại | Vì sao |
| --- | --- | --- |
| **Số đếm của từng kỳ**, tới ~12 kỳ: việc xong mỗi tuần, đơn mỗi ngày, khách mới mỗi tháng | **Cột**, số trên đầu mỗi cột | Mỗi kỳ là một con số rời người ta muốn đọc; cột ghi đủ số, không phải rê chuột |
| Mức tại từng thời điểm hoặc tỷ lệ: số người dùng đang hoạt động, tỷ lệ huỷ, số dư, luỹ kế. Doanh thu theo tháng khi cái cần đọc là xu hướng | Đường | Giá trị chảy liền, cái cần thấy là dáng lên xuống |
| Số đếm từng kỳ nhưng quá ~12 kỳ (30 ngày, 52 tuần) | Đường | Cột mảnh quá, số trên đầu cột chồng nhau |

Các công cụ quản lý dự án phổ biến vẽ "việc xong mỗi tuần" bằng cột. Vẽ 8
tuần bằng đường thì chỉ đọc được số tuần cuối.

## Công thức dùng được ngay

**Vùng vẽ giãn theo card, không đóng cứng.** Card biểu đồ thường bị lưới kéo cao
hơn nội dung. Dùng `flex-1 min-h-[14rem]` cho vùng vẽ để cột nở ra lấp đầy, cột
cao lên thì chênh lệch giữa các giá trị cũng đọc rõ hơn. Đừng đóng `h-56` rồi
`mt-auto` đẩy xuống đáy.

Giãn hết cỡ rồi mà vẫn dư nhiều thì **cho card ngắn lại** (bỏ `row-span`), đừng
tự nghĩ ra nội dung lấp vào. Lúc giao gợi ý một dòng chỗ đó có thể thêm gì, xem
luật `S5` trong `../../SKILL.md`.

**Biểu đồ cột**, hình cần đạt (có thư viện thì dựng bằng thư viện, xem mục trên):

```html
<div class="flex min-h-[14rem] flex-1 items-end gap-2 sm:gap-3">
  <div class="flex h-full flex-1 flex-col justify-end gap-2">
    <p class="text-center text-xs font-medium text-muted">16</p>
    <!-- mx-auto w-full max-w-8: cột tối đa 32px, nằm giữa khe của nó -->
    <div class="mx-auto w-full max-w-8 rounded-t-md bg-chart-fill" style="height: 80%"></div>
  </div>
  <!-- các cột khác, cùng bg-chart-fill; kỳ đang chạy (cột cuối) bg-chart-fill/35 -->
</div>

<div class="mt-3 flex gap-2 border-t border-border pt-3 sm:gap-3">
  <p class="flex-1 text-center text-xs text-muted">T1</p>
  <!-- nhãn trục, cùng gap với cụm cột để thẳng hàng -->
</div>
```

Nhãn trục phải dùng **đúng `gap` với cụm cột**, lệch một bậc là cả hàng nhãn
trượt khỏi cột.

- **Cột tối đa 32px** (`max-w-8`), khe còn lại để trống. Để `flex-1` giãn hết thì 8 cột trong card rộng thành 8 khối đen 56px, cả biểu đồ là một mảng đen nặng nhất màn, nặng hơn tên trang và hàng số (ở 32px mảng đen mất, số trên đầu cột vẫn đọc như cũ). Màn hẹp cột tự co theo khe.
- **Kỳ đang chạy (tuần này, tháng này) là cột nhạt `bg-chart-fill/35`, nhãn trục ghi "Tuần này"**, số trên đầu vẫn ghi. Kỳ chưa hết mà vẽ cùng màu với các kỳ đủ thì cột thấp đọc ra "tuần này tụt", cột cao đọc ra "đã vượt" trong khi tuần còn hai ngày. Hàng số liệu đã so "cùng thời điểm tuần trước", biểu đồ cũng phải nói tuần này chưa xong. Các công cụ phân tích phổ biến đều vẽ kỳ đang chạy khác đi (nhạt hoặc nét đứt).
- **Mới một kỳ thì chưa phải biểu đồ**, như biểu đồ đường: một cột đứng giữa khung trống là một cột đen không so với gì. Thay vùng vẽ bằng khối chữ, giữ chiều cao: số `text-2xl font-semibold tabular-nums` + "Việc xong tuần này. Từ tuần sau sẽ thấy xu hướng".

**Biểu đồ cột nhóm** (hai, ba kỳ cạnh nhau):

- Cột trong một nhóm cách nhau `gap-1.5`, nhóm cách nhau rộng hơn hẳn (`gap-6` trở lên), để mắt gom đúng nhóm.
- **Thời gian đi từ trái sang phải**, như trục của biểu đồ đường: kỳ cũ bên trái, **kỳ mới nhất bên phải và đậm nhất**. Chú giải xếp cùng thứ tự. Để 2026 đứng trái 2024 thì nhóm tăng trưởng nhìn như đi xuống.
- Tối đa ba chuỗi. Nhiều hơn thì tách biểu đồ hoặc chuyển bảng.
- **Bằng 0 khác chưa có số**, như biểu đồ đường: bằng 0 thì không có cột, ghi `0` sát đáy; chưa có số (kênh chưa mở năm đó) thì ghi `—` sát đáy, đừng ghi `0`.
- Tên nhóm dài `truncate` kèm `title`, một dòng. Màn hẹp không đủ chỗ thì cụm cột cuộn ngang **trong khung** (`overflow-x-auto`), trang không cuộn (`R1`).
- Đơn vị ghi một lần ở mô tả hoặc tiêu đề card ("triệu đồng"), không lặp trên từng cột.

**Donut** (tỷ lệ trên tổng, tối đa bốn phần):

- Vòng bên trái, bảng chú giải bên phải (màn hẹp: vòng trên, bảng dưới). Giữa vòng là tổng `text-2xl font-semibold tabular-nums` + nhãn `text-sm text-muted`.
- **Xếp lớn xuống nhỏ**, bắt đầu từ 12 giờ đi theo chiều kim đồng hồ, phần lớn nhất đậm nhất theo thang ở trên. Giữa các phần một khe trắng mảnh.
- Bảng chú giải là danh sách chia dòng: chấm · tên (`min-w-0 flex-1 truncate` + `title`) · số (`font-medium tabular-nums`) · phần trăm (`text-muted tabular-nums`, cột rộng cố định). Số và phần trăm không bao giờ bị đẩy xuống dòng.
- Phần dưới 1% vẫn vẽ một vệt tối thiểu để thấy được. **Phần trăm cùng số chữ số lẻ trong một biểu đồ**: có phần dưới 1% thì cả bảng một chữ số lẻ, không thì số nguyên. Tổng các dòng làm tròn phải ra 100.
- **Tổng bằng 0**: chỉ còn rãnh `bg-foreground/5`, giữa vòng ghi `0`, cột phần trăm để trống (không `0%`, như `0/0`).
- Quá bốn phần thì dùng danh sách thanh tiến độ ở dưới, xếp lớn dần.

**Thanh tiến độ trong danh sách:**

```html
<li class="py-3 first:pt-0">
  <div class="flex items-baseline justify-between gap-3">
    <p class="min-w-0 flex-1 truncate text-sm font-medium text-foreground">Thiết kế giao diện</p>
    <p class="shrink-0 text-sm font-medium text-foreground">92%</p>
  </div>
  <!-- Rãnh là lớp phủ bg-foreground/5, không bg-background: nền tối bg-background tối hơn card, rãnh thành
       vệt đen nặng (M21). Bản sáng hai cách cùng một màu. -->
  <div class="mt-2 h-2 rounded-full bg-foreground/5">
    <div class="h-2 rounded-full bg-primary" style="width: 92%"></div>
  </div>
</li>
```

Rãnh nền dùng `--background`, không dùng `--border`. Thanh `h-2`, bo `full`.
Con số phần trăm ghi ở đầu dòng, không đặt bên trong thanh.

**Thanh trong danh sách luôn `bg-primary`**, kể cả khi mục đó có chuyện cần chú ý
(dự án có việc quá hạn). Thanh nói đúng một điều là đã xong bao nhiêu; chuyện cần
chú ý nói bằng chữ ở dòng phụ, và **chỉ cụm đó** `text-amber-700`, phần còn lại
xám: `112 / 120 việc · <span class="text-amber-700">2 việc quá hạn</span>`, cùng
cách tô với hạn trong `list-row.md`. Tô cả thanh hổ phách thì dự án 93% đọc ra
"tiến độ có vấn đề", vài thanh cam thành thứ nặng nhất màn.
Màu theo trạng thái (dưới đây) chỉ cho **thanh đứng riêng**, nơi màu nói về chính
đại lượng thanh đo (dung lượng gần đầy). Mục xong 100% thì thanh emerald như
thanh đứng riêng. **Ngoại lệ: thanh trần trong danh sách** (ngân sách từng danh mục, hạn mức thẻ): màu nói
về chính đại lượng thanh đo, nên tô như thanh dung lượng, `bg-primary` khi ổn, amber khi sắp chạm, đỏ khi
vượt, kèm dòng phụ bằng chữ ("Sắp vượt · còn 350.000 đ", "Đã vượt 65.000 đ"). Các app ngân sách phổ biến
đều tô vậy.

**Thanh tiến độ đứng riêng** (dung lượng, checklist): hàng trên là
nhãn trái + số phải, thanh ở giữa, một dòng phụ `text-xs text-muted` bên dưới.

- `role="progressbar"` + `aria-valuenow`, `aria-valuemin`, `aria-valuemax`, `aria-label` bằng đúng nhãn. Trình đọc màn hình không thấy độ dài thanh.
- **Màu theo trạng thái, đúng bảng trạng thái của app**: đang chạy `bg-primary`; **xong** `bg-emerald-600` (checklist đủ); cần chú ý `bg-amber-500`; hỏng hay đầy `bg-red-500`. Ngưỡng đổi màu (vd. dung lượng từ 80%) là của người dùng, truyền qua prop `tone`. Dòng phụ đổi màu theo (`amber-700`, `red-600`) và nói bằng chữ, vì màu thanh một mình không đủ.
- **Xong mà thanh vẫn đen đầy** thì trông y hệt "đang chạy tới 99%". Thanh đứng riêng (dung lượng, checklist) xong là emerald.
- **Tải tệp** (một hay nhiều tệp) không dùng khuôn này: theo `file-upload.md`. **Hai độ dày là cố ý, đừng gộp**: thanh ở đây (`h-2`) là **con số chính** của khối, người ta đọc nó để so; thanh tải tệp (`h-1`) chỉ là **trạng thái tạm** của một dòng mà nội dung chính là tên tệp, xong là biến mất. Demo "tiến độ tải file" trong bộ progress bar cũng dựng theo khuôn tải tệp. Thanh mảnh `h-1`, chỉ tệp đang tải mới có thanh; xong và hỏng thì bỏ thanh, bỏ số %, chỉ còn một dòng chữ; Thử lại là nút chữ sau lý do.
- **Không có gì để đếm** (checklist 0 việc): không ghi `0/0`, ô số để trống, thanh rỗng, dòng phụ "Chưa có việc nào". `0/0` đọc như lỗi chia cho 0.
- **Một kiểu viết số cho cả app**: `12,4 / 20 GB` và `4 / 6 việc`, gạch chéo có dấu cách hai bên. Chỗ có cách chỗ không là lệch. Số `tabular-nums`.

⚠️ **Luật cũ đã bỏ, đừng hồi sinh:** tải hỏng giữ thanh đỏ dừng giữa chừng kèm số %, nút viền "Thử lại" cuối hàng, cột hành động `w-20`; tải xong giữ thanh xanh lá đầy + `100%`. Lên danh sách nhiều tệp thì thành một dàn sọc đen đỏ xanh, và tệp hỏng không còn ✕ để bỏ. Khuôn mới ở `file-upload.md`.

**Biểu đồ đường** (xu hướng theo tháng, theo ngày):

- Có thư viện thì cấu hình theo bảng ở mục "Vẽ bằng thư viện"; chưa có thì một `<svg>` với `<polyline>` là đủ; chỉ đề xuất thư viện khi có nhu cầu ở mục 3 phía trên.
- Một đường `stroke-2` màu `--primary`, không tô vùng dưới, không bo cong làm sai giá trị (`monotone` thì được, `basis`/`cardinal` vọt quá điểm thật thì không).
- **Chỉ một chấm và một con số, ở điểm cuối** (`size-2.5`, số `text-xs font-semibold tabular-nums` cạnh chấm). Rê chuột hay dùng mũi tên thì chấm và số dời sang tháng đó, **không mở thêm tooltip nổi**: cùng một chỗ, chỉ đổi vị trí (`N1`, `N3`). Dựng một ví dụ tĩnh cho trạng thái đang rê (`N2`).
- **Nhãn trục bị thưa thì số phải kèm mốc**: "13/09 · 70,9 tr đ", không chỉ "70,9 tr đ". 30 ngày mà trục chỉ ghi 02/09, 07/09, 12/09 thì rê vào một điểm ra một con số không biết của ngày nào. Mọi thư viện biểu đồ phổ biến đều ghi ngày ở đầu tooltip; skill không dùng tooltip nổi nhưng không bỏ ngày. Mốc là `text-muted font-normal`, số giữ `font-semibold`. **Mốc chưa trọn kỳ luôn ghi tên kỳ**: "Hôm nay · 44,4 tr đ", "Tuần này · 330,1 tr đ", "Tháng 9 · 1,41 tỷ đ": số của ngày chưa hết đứng một mình ở cuối đường đọc ra "hôm nay tụt". Trục ghi đủ mọi mốc (12 tháng) thì số đứng một mình được, mốc nằm ngay dưới.
- **Nhãn đặt về phía không có đường.** Mặc định số nằm trên chấm, nhưng điểm thấp hơn điểm kề thì đoạn nối đi lên đúng chỗ đó và chữ đè lên đường (nền `bg-surface` sau chữ cắt đôi đường, trông như đường đứt). Chọn theo hai điểm kề: cả hai thấp hơn hoặc bằng (đỉnh) thì **trên**; cả hai cao hơn (đáy) thì **dưới** (`top: calc(y + 0.625rem)`); một cao một thấp (sườn) thì **trên, lệch về phía điểm kề thấp hơn** (căn mép phải chữ vào chấm khi điểm thấp ở bên trái, mép trái khi ở bên phải). Điểm đầu, điểm cuối chỉ có một điểm kề: kề thấp hơn thì trên, cao hơn thì dưới. Hai điểm chênh nhau dưới 2% chiều cao vùng vẽ thì coi là bằng nhau: không vậy thì điểm chỉ thấp hơn bên cạnh 0,5 tr bị coi là đáy, số rớt xuống dưới đè lên đoạn gần như nằm ngang.
  **Chỗ đó không vừa thì thử chỗ khác, theo thứ tự:** phía theo hai điểm kề → phía đối diện → **ngang cạnh chấm** (căn giữa theo chấm, cách chấm 8px, ưu tiên bên không có điểm kề hoặc bên điểm kề thấp hơn). Lấy chỗ đầu tiên vừa **nằm trọn trong vùng vẽ** (trên đường 0, dưới đỉnh) vừa **không chạm đường**; tính bằng toạ độ mọi đoạn nằm dưới khung chữ đo được, không chỉ hai đoạn nối vào chấm, và không đoán theo số: ở 375px, 30 điểm chỉ có chừng 260px, chữ rộng ~100px trùm qua cả chục đoạn. Cả bốn chỗ đều chạm (đường dày, màn hẹp) thì giữ cách căn của chỗ đầu tiên, đẩy chữ lên hẳn trên phần đường nằm dưới nó (cách 6px), rồi thử xuống hẳn dưới; vẫn không sạch thì lấy chỗ trong vùng vẽ chạm ít đoạn nhất. **Dưới đường 0 là chỗ của hàng nhãn trục**: số rơi xuống đó đọc ra một nhãn trục thứ hai. Ví dụ "Hôm nay · 6,8 tr đ" sát đáy, điểm kề cao hơn: xuống dưới thì lòi khỏi vùng vẽ, sát nhãn trục; đặt ngang bên trái chấm thì vừa, vì đoạn đứt đi gần như thẳng đứng.
  Probe đo cả hai lỗi ("Nhãn số đè lên đường biểu đồ", "Nhãn số lòi ra ngoài vùng vẽ").
- **Tab vào biểu đồ: số của mốc đang đứng hiện ra**, như rê chuột tới mốc đó; không vòng quanh chấm (`I13`).
- **Đáy là 0**, đường kẻ đáy `border-border`, nhãn tháng `text-xs text-muted` bên dưới. Tháng bằng 0 thì chạm đáy.
- **Không có số khác với bằng 0.** Tháng chưa có dữ liệu (chưa tới, chưa ghi nhận) thì **đứt đường** ở đó, không kéo xuống đáy: kéo xuống 0 là nói dối "tháng đó không bán được gì".
- **Màn hẹp**: 12 nhãn tháng ở 375px sát vào nhau. Dưới `sm` ghi **cách một nhãn, đếm ngược từ nhãn cuối** (nhãn cuối, cuối − 2, cuối − 4…); đường vẫn đủ 12 điểm. Đừng đếm xuôi "nhãn lẻ + nhãn cuối": số điểm chẵn thì nhãn cuối đứng sát nhãn lẻ cuối cùng, "14/09 21/09" dính nhau ở 375px. Cột cũng theo luật này.
- **Mới một điểm thì chưa phải biểu đồ.** Một chấm lơ lửng giữa khung trống trông như vẽ lỗi. Thay vùng vẽ bằng khối chữ, **giữ nguyên chiều cao**: con số `text-2xl font-semibold tabular-nums` + dòng `text-sm text-muted` "Số của tháng 9. Từ tháng sau sẽ thấy xu hướng" (`N6`). Luật này cho dữ liệu **chưa có** điểm thứ hai (tháng đầu mở bán). Trang báo cáo mà người dùng tự chọn khoảng một ngày thì không rơi vào đây: chia nhỏ mốc xuống theo giờ (xem "Trang báo cáo" trong `../layouts/app/report.md`). Thay biểu đồ bằng một con số thì số đó trùng ô "Doanh thu" ngay trên (`N3`).
- **Rỗng**: giữ chiều cao, câu nói vì sao và bao giờ có: "Chưa có doanh thu. Số liệu hiện sau đơn hàng đầu tiên" (`components/empty-state.md`). Bỏ luôn đường đáy: đáy không nhãn đứng một mình trông như đường kẻ lạc.
- `role="img"` + `aria-label` tóm tắt bằng chữ ("Doanh thu 12 tháng, tăng từ 0,9 tỷ lên 1,46 tỷ"); điểm nhận focus thì mỗi điểm có `aria-label` tháng + số.

**Hàng ô số liệu:** một khối chia `divide-x`, không phải mấy card rời. Xem
`layouts/app.md`.

---

## Ô số liệu ở màn hẹp

Đây là chỗ vỡ nhiều nhất, và chỉ lộ ra khi thu cửa sổ xuống 375px.

- **Mobile là 2×2**: `grid-cols-2 lg:grid-cols-4`, như hầu hết app trên điện thoại. Một cột thì bốn ô số ngắn (4, 140, 5, 23) xếp dọc cao 417px, chiếm gần hết màn đầu ở 375px, biểu đồ và việc hôm nay bị đẩy khỏi tầm nhìn; 2×2 còn 209px (chủ dự án duyệt). Ở 375px mỗi ô còn **138px cho chữ số** (`text-xl`, ô `p-4`): vừa `1.284.500` (98px), `184,5 tr đ` (91px), `1,28 tỷ đ` (80px); không vừa `1.284.500.000 đ` (161px).
  - **Có số không vừa 138px** (tiền đầy đủ tới hàng tỷ): gợi ý rút gọn theo "Số quá 9 chữ số" bên dưới. Người dùng muốn giữ số đầy đủ thì hàng đó về `grid-cols-1 sm:grid-cols-2 lg:grid-cols-4`, không để số xuống dòng hay tràn.
  - **Số ô lẻ** (3, 5): 2 cột là một ô đứng lẻ ở hàng dưới (`R3`), nên đi thẳng `grid-cols-1 sm:grid-cols-3`. 6 ô thì 2 cột được.
  - Luật cũ (đã bỏ): "Mobile là một cột" cho mọi hàng số, vì sợ số dài; phần lớn hàng số trên màn tổng quan là số đếm ngắn.
  - Ô trong panel trượt: xem mục dưới.
- **Trong panel trượt hay cột hẹp: lưới 2×2 cố định, một khung, số nhỏ hơn tên.** Panel 448px không phải trang tổng quan: số ở đây là thông tin phụ của một bản ghi, không phải nhân vật chính. Bốn card rời `rounded-2xl p-5` với số `text-3xl` là thứ nặng nhất panel, nặng hơn cả tên khách (các CRM lớn để số của khách ở cỡ chữ thường). Dựng một khung, kẻ chia bằng khe 1px, số `text-lg font-semibold`, không bao giờ lớn hơn cỡ tên ở header panel. Dòng so sánh chỉ còn icon + số (kỳ ghi một lần, xem "Dòng so sánh") nên 2 cột ở 375px vẫn vừa, không phải xếp thành bốn ô dọc dài.

```html
<p class="mb-2 text-xs text-muted">12 tháng gần nhất, so với 12 tháng trước</p>
<div class="grid grid-cols-2 gap-px overflow-hidden rounded-xl border border-border bg-border">
  <div class="min-w-0 bg-surface p-4">
    <p class="text-xs font-medium text-muted">Doanh thu</p>
    <p class="mt-1 text-lg font-semibold tabular-nums text-foreground">184,5<span class="ml-1 text-muted">tr đ</span></p>
    <p class="mt-0.5 flex items-center gap-1 text-xs font-medium tabular-nums text-emerald-700">
      <i data-lucide="trending-up" class="size-3.5"></i>12,4%
    </p>
  </div>
  <!-- 3 ô còn lại cùng khuôn -->
</div>
```
- **Mỗi ô phải có `min-w-0`.** Grid item mặc định không chịu co nhỏ hơn nội dung, thiếu dòng này là cả trang tràn ngang.
- **Số của các ô cùng hàng luôn thẳng một đường, kể cả khi có nhãn xuống dòng.** Mỗi ô là `grid row-span-2 grid-rows-subgrid content-start` (ba tầng thì `row-span-3`), khung ngoài không cần khai hàng: hàng nhãn cao theo nhãn dài nhất, số cả hàng cùng nằm dưới đó. Không có subgrid thì một nhãn hai dòng đẩy riêng số của ô đó xuống 16px.
- **Nhãn có kỳ ngắt sau dấu `·`, không ngắt giữa kỳ**: `Đơn đã giao&nbsp;· 12&nbsp;tháng` ra "Đơn đã giao ·" / "12 tháng". Để khoảng trắng thường thì trình duyệt ngắt "· 12" / "tháng"; dán `&nbsp;` sau dấu thì dấu `·` rơi xuống đầu dòng.
- **Cỡ số giảm một bậc ở mobile**: `text-xl sm:text-2xl`.
- **Dùng `tabular-nums`** cho mọi con số. Chữ số đều bề ngang thì các ô thẳng cột nhau, và số không nhảy khi đổi giá trị.

```html
<!-- Kẻ chia bằng khe 1px lộ nền --border (như lưới trong panel): divide-x không kẻ được đường ngang giữa hai hàng của 2×2 -->
<div class="grid grid-cols-2 gap-px overflow-hidden rounded-2xl border border-border bg-border lg:grid-cols-4">
  <div class="min-w-0 bg-surface p-4 sm:p-5">
    <p class="text-xs font-medium text-muted">Đang làm</p>
    <p class="mt-1 text-xl font-semibold tracking-tight tabular-nums text-foreground sm:text-2xl">1.284.500</p>
    <p class="mt-1 text-xs text-muted">Trải trên 4 dự án</p>
  </div>
</div>
```

### Dòng so sánh và đơn vị tiền

```html
<div class="min-w-0 p-5">
  <p class="text-xs font-medium text-muted">Doanh thu tháng này</p>
  <p class="mt-1 text-xl font-semibold sm:text-2xl tracking-tight tabular-nums text-foreground">
    1.284.500.000<span class="ml-1 font-semibold text-muted">đ</span>
  </p>
  <p class="mt-1 flex items-center gap-1 text-xs text-muted">
    <i data-lucide="trending-up" class="size-3.5 text-emerald-700"></i>
    <span class="font-medium tabular-nums text-emerald-700">12,4%</span> so với tháng trước
  </p>
</div>
```

- **Hai luật tiền dưới đây cho tiền VND trong copy tiếng Việt.** Tiền tệ khác hoặc copy tiếng Anh thì format theo locale (`T28`).
- **Đừng format tiền bằng `Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' })`**: nó tự sinh ra `₫`. Format số bằng `Intl.NumberFormat('vi-VN')` rồi tự gắn `đ`. Grep `currency: 'VND'` trước khi đổ lỗi cho chỗ khác.
- **Đơn vị tiền dùng chữ `đ` thường, không dùng ký hiệu `₫`.** Chữ `₫` có sẵn một vạch dưới trong chính mặt chữ, CSS không bỏ được: ở cỡ lớn trông như link, thu nhỏ thì thành một vệt gạch lí nhí. `đ` **cùng cỡ với số**, `font-semibold`, chỉ đổi sang `text-muted` và cách `ml-1`: màu mờ đã đủ tách đơn vị khỏi giá trị. Dự án đã quen dùng `₫` thì theo dự án.
- **Số quá 9 chữ số trong ô hẹp**: gợi ý (người dùng quyết) rút gọn `1,28 tỷ đ`, số đầy đủ để trong `title`. Ô số liệu để đọc xu hướng, không để đối soát từng đồng.
- **Dòng so sánh**: icon `trending-up` / `trending-down` `size-3.5` + phần trăm `font-medium` có màu + phần còn lại `text-muted`. Chỉ icon và con số mang màu, không tô cả câu.
- **Màu theo tốt/xấu, không theo lên/xuống.** Doanh thu tăng là xanh, nhưng chi phí hay số đơn huỷ tăng là đỏ. Để một prop kiểu `tone="positive" | "negative" | "neutral"` cho người dùng quyết, đừng suy màu từ dấu của con số. Xanh `emerald-700`, đỏ `red-700`: chữ `text-xs` cần 4.5:1, `emerald-600` và `red-500` không đạt.
- **Không đổi**: icon `minus`, chữ `text-muted`, không màu. **Một ô không có kỳ trước** (các ô khác có): một câu `text-muted` ngắn ("Chưa có kỳ trước"). Hai ca này vẫn **giữ đúng một dòng**, để các ô trong hàng cao bằng nhau. Ngưỡng coi là "không đổi" do người dùng quyết.
- **Kỳ so sánh ghi MỘT lần cho cả hàng, không lặp ở từng ô.** Bốn ô cùng đuôi "so với 2025" là một ý nói bốn lần (`N3`), và chính cái đuôi đó làm ô hẹp vỡ dòng. Ghi kỳ một lần ở tiêu đề mục hoặc dòng `text-xs text-muted` trên hàng ô ("12 tháng gần nhất, so với 12 tháng trước"), mỗi ô chỉ còn icon + số ("↗ 12,4%", "↗ 0,6 điểm"). Nhãn ô cũng bỏ kỳ: "Doanh thu", không "Doanh thu 12 tháng" khi ô bên cạnh là "Số đơn" trơn, vì đọc ra hai ô hai kỳ khác nhau. **Kỳ so phải cùng loại với kỳ đo**: đo 12 tháng gần nhất thì so với 12 tháng trước đó, không so với "năm 2025".
- **Cả hàng không có kỳ trước thì cũng nói một lần**, ở đúng chỗ ghi kỳ ("Khách mới, chưa có kỳ trước để so"), các ô bỏ hẳn dòng so sánh. Bốn ô cùng dòng "Chưa có kỳ trước" là cùng lỗi lặp ở trên. Ngoại lệ: trên cùng màn có số khác kỳ đếm cùng thứ (tab "Đơn hàng 42" trọn đời) thì riêng ô đó ghi kỳ trong nhãn, "Đơn đã giao · 12 tháng" (`layouts/app/record-detail.md`, "Trang chi tiết bản ghi").
- **Cả hàng rỗng (khách chưa có đơn nào) thì không dựng lưới số 0.** Bốn ô "0 đ", "0 đơn", "—", "—" là bốn khung chỉ để nói một ý "chưa có gì". Thay cả hàng bằng một khung gọn cùng viền và **cùng nền `bg-surface`** với các card (khung trong suốt nằm trên nền trang thì chỉ còn một dòng chữ xám lơ lửng, viền `--border` gần như không thấy), một câu `text-sm text-muted` nói vì sao và bao giờ có: "Chưa có đơn nào. Số liệu hiện sau đơn đầu tiên" (`components/empty-state.md`, `N6`). Có nút tạo đơn ở chỗ khác trên màn thì không lặp nút ở đây. **Trang chi tiết có tab Đơn hàng thì bỏ hẳn hàng số**, không dựng cả khung gọn: tab rỗng đã nói câu đó (`layouts/app/record-detail.md`, "Trang chi tiết bản ghi").
- **`—` chỉ khi không tính được** (mẫu số bằng 0: chưa có đơn nào thì chưa có tỷ lệ hoàn). Có 3 đơn, không đơn nào hoàn thì là `0%`, không phải `—`: `—` ở đó đọc ra "thiếu dữ liệu" trong khi số đã rõ.
- **Ô không có giá trị thì `—` `text-muted font-normal`**, cùng ký hiệu với ô trống trong bảng (`T18`). `—` tô `text-foreground font-semibold` ở `text-2xl` thành một vạch đen dày, đọc như con số chứ không như "trống".
- **Nhãn đã nói đơn vị thì số không lặp đơn vị.** Nhãn "Số đơn" thì số là `24`, không `24 đơn`; nhãn "Khách hàng" thì `1.204`, không `1.204 khách`. Đơn vị chữ chỉ gắn khi nhãn chưa nói (nhãn "Đơn hàng" có thể `24 đơn`, nhưng thường thừa).
- **Số rút gọn thì hậu tố đi cùng đơn vị, cùng một span mờ**: `184,5` rồi `tr đ` `text-muted`, không để `tr` đen mà `đ` xám (đọc thành "184,5 tr" là số, "đ" là đơn vị, trong khi "tr" cũng là đơn vị). Chữ rút gọn: `nghìn`, `tr`, `tỷ`.
- **Dòng so sánh luôn một dòng, `text-xs`**, kể cả ca có số. Đừng để icon và phần trăm ở dòng trên, "so với tháng trước" rớt xuống dòng dưới: đọc thành hai ý rời, và ô cao thêm một dòng. Ô hẹp không đủ chỗ thì rút đuôi câu ("so với T8", "so với kỳ trước"), không xuống dòng. Câu ca không có kỳ trước cũng vậy: "Chưa có số kỳ trước để so" vỡ thành hai dòng, chữ "so" nằm một mình, nên dùng "Chưa có kỳ trước".
- **`%` dính vào số, không cách**: `2,8%`, `12,4%`, cùng một kiểu ở số chính lẫn dòng so sánh (`N5`). Khác `đ` và `đơn`: đơn vị là chữ thì cách `ml-1`, ký hiệu `%` thì không. Số chính có `%` thì `%` `text-muted` như `đ`.
- **Số đếm nhỏ thì so bằng chênh lệch, không bằng phần trăm.** Kỳ trước dưới 20 (việc quá hạn, dự án đang chạy) thì ghi "↗ 2", không "↗ 66,7%": từ 3 lên 5 việc quá hạn mà đọc 66,7% thì tưởng cháy nhà. Nhãn ô đã nói đơn vị nên số trơn, không "2 việc". Các ô trong một hàng được phép khác kiểu (ô 140 việc đang mở vẫn ghi %).
- **Chỉ số đã là tỷ lệ thì so bằng điểm phần trăm, không bằng phần trăm của phần trăm.** Tỷ lệ huỷ từ 2,2% lên 2,8% ghi "↗ 0,6 điểm", không ghi "↗ 27,3%": 27,3% đọc như tỷ lệ huỷ tăng vọt thêm 27 điểm. Cách tính là logic người dùng; skill chỉ để chỗ và nhãn "điểm".

### Sparkline trong ô số liệu

```tsx
// Cả hàng dùng chung một cờ: có ít nhất một ô vẽ được thì mới giữ chỗ
const rowHasSparkline = tiles.some((tile) => tile.points.length >= 2);

<div className="flex min-w-0 flex-col p-5">
  {/* nhãn, số, dòng so sánh */}
  {tile.points.length >= 2 ? (
    <svg aria-hidden="true" className="mt-auto h-10 w-full pt-4">{/* polyline + chấm cuối */}</svg>
  ) : rowHasSparkline ? (
    // Giữ chỗ chỉ để cao bằng ô bên cạnh. Hàng 2×2 ở mobile vẫn có ô bên cạnh nên giữ;
    // chỉ hàng về một cột ở mobile (số dài, số ô lẻ) mới thêm max-sm:hidden
    <div aria-hidden="true" className={cn("mt-auto h-10 pt-4", isSingleColumnOnMobile && "max-sm:hidden")} />
  ) : null}
</div>
```

Không đặt `min-h` cố định cho ô: chiều cao ô phải đến từ nội dung, để cả hàng
chưa có sparkline thì ô tự ngắn lại (ô giữ `min-h` hoặc chỗ giữ không phụ thuộc cả hàng thì
desktop vẫn trống).

- Một đường `stroke-[1.5]` `--primary`, cao `h-10` đến `h-12`, rộng hết ô, dính đáy ô (`mt-auto`). Chấm `size-1.5` ở điểm cuối. Không trục, không nhãn, không rê chuột: ô là để liếc hình dáng.
- **Không lấy đáy 0**, khác biểu đồ đường: kéo giãn theo min–max của chuỗi để thấy được dáng. Biểu đồ đường thì có số để đọc, sparkline chỉ có dáng.
- **Đường luôn một màu `--primary`**, kể cả khi dòng so sánh đỏ. Màu tốt/xấu đã nói ở dòng so sánh; tô đường đỏ nữa là hai tín hiệu cho một ý (`N3`).
- Mọi ô trong hàng cùng số điểm, cùng khoảng thời gian, sparkline cùng chiều cao.
- **Chưa đủ hai điểm** (tháng đầu tiên): không vẽ, không chấm lẻ, không đường ngang giả. **Giữ chỗ chỉ khi có ô bên cạnh để khớp** (`N1`):
  - Cùng hàng có ô **có** sparkline: ô thiếu giữ chỗ bằng đúng chiều cao sparkline, để các ô cao bằng nhau.
  - **Hàng về một cột ở mobile** (số dài không rút gọn, số ô lẻ; mặc định là 2×2, xem "Ô số liệu ở màn hẹp"): các ô xếp dọc, không có ô nào bên cạnh, giữ chỗ chỉ là một khoảng trắng lớn dưới mỗi ô. Chỗ giữ `max-sm:hidden`. Hàng 2×2 thì giữ chỗ cả ở mobile, vì ô cạnh bên vẫn cần cao bằng.
  - **Cả hàng đều chưa có** sparkline: bỏ hẳn chỗ giữ ở mọi cỡ màn, ô chỉ cao đến dòng so sánh.
- `aria-hidden="true"` trên `<svg>`: xu hướng đã nói bằng chữ ở dòng so sánh.

### Ô số tiến tới mục tiêu ⚑

Chỉ số có mục tiêu trong kỳ (doanh thu tháng, số khách mới quý): dưới số chính là thanh tiến độ
thay cho sparkline.

```html
<div class="@container flex min-w-0 flex-col p-5">
  <p class="text-xs font-medium text-muted">Doanh thu tháng 11</p>
  <p class="mt-1 text-xl font-semibold tracking-tight tabular-nums text-foreground sm:text-2xl">672<span class="ml-1 text-muted">tr đ</span></p>
  <div class="relative mt-auto pt-4">
    <div role="progressbar" aria-label="Doanh thu tháng 11 so với mục tiêu" aria-valuenow="67" aria-valuemin="0" aria-valuemax="100" class="h-2 rounded-full bg-foreground/5">
      <div class="h-2 rounded-full bg-primary" style="width: 67%"></div>
    </div>
    <!-- Vạch nhịp: chỗ lẽ ra phải tới hôm nay, chỉ khi có nhịp kỳ vọng. Cao hơn thanh, nhô lên trên;
         ring màu nền tách vạch khỏi phần đã tô (thanh primary gần đen thì vạch tối vẫn thấy) -->
    <div aria-hidden="true" class="absolute bottom-0 h-3.5 w-0.5 rounded-full bg-foreground/60 ring-2 ring-surface" style="left: 23%"></div>
  </div>
  <p class="mt-2 flex flex-col gap-0.5 text-xs text-muted tabular-nums @[17rem]:flex-row @[17rem]:items-baseline @[17rem]:justify-between">
    <span class="whitespace-nowrap"><span class="font-medium text-foreground">67%</span> mục tiêu</span>
    <span class="whitespace-nowrap">672 / 1.000 tr đ</span>
  </p>
</div>
```

- **Phần trăm và "đạt / mục tiêu" cùng hiện** (5/6 nguồn): trái "67% mục tiêu", phải "672 / 1.000 tr đ".
  Chỉ phần trăm thì không biết mục tiêu bao nhiêu; chỉ phân số thì phải tự chia.
- **Hai cụm đứng cạnh nhau hay xếp hai dòng theo bề rộng Ô, không theo bề rộng màn**: ô là
  `@container`, dòng dưới `flex flex-col gap-0.5 @[17rem]:flex-row @[17rem]:items-baseline
  @[17rem]:justify-between`, mỗi cụm `whitespace-nowrap`. Bốn ô cùng hàng cùng bề rộng nên cả hàng
  cùng một kiểu. Theo `sm:` thì ở 1440px có sidebar ô chỉ còn ~248px chữ: "Chậm 10% so với nhịp" cạnh
  "4.020 / 30.000" hết chỗ, phân số gãy "4.020 /" / "30.000" (chủ dự án chê "lệch"). Để `flex-wrap` thì ô
  "4 / 4" một dòng, ô bên cạnh hai dòng.
- **Đuôi câu rút theo ô**: `Chậm 10%<span class="@max-[12rem]:hidden"> so với nhịp</span>` (ô 2×2 ở
  375px chỉ 138px). Chữ và đuôi nằm trong **một** span, icon là con kia: để đuôi thành con thứ ba
  của `inline-flex gap-1` thì giữa "10%" và "so" thừa một khoảng.
- **Thanh, không vòng.** Nguồn chia đôi giữa thanh và vòng, nhưng skill đã dùng thanh cho mọi tiến độ
  (`N5`): một app một hình cho "đã được bao nhiêu". Vòng chỉ khi dự án đã dùng vòng, hoặc app điện thoại sức khoẻ, thể
  dục, ăn uống, thói quen, tiết kiệm (vòng và cung của `J17` trong `../mobile/charts.md`); app đó dùng vòng thì dùng vòng ở mọi
  chỗ "đã được bao nhiêu".
- **Màu thanh** theo thanh đứng riêng ở trên: đang chạy `bg-primary`, **đạt mục tiêu** `bg-emerald-600`.
  **Vượt mục tiêu**: thanh đầy, emerald, phần trăm vẫn ghi số thật "112% mục tiêu".
- **Chậm nhịp** (chỉ khi dự án có nhịp kỳ vọng, cách tính là logic người dùng `N10`): thanh giữ
  `bg-primary`, thêm **vạch nhịp** (2/2 nguồn có vạch đánh dấu trên thanh) ở chỗ lẽ ra phải tới hôm nay,
  và dòng phụ đổi trái thành "Chậm 12% so với nhịp" `text-amber-700` kèm icon. Không tô cả thanh
  amber: như "Thanh trong danh sách", thanh chỉ nói đã được bao nhiêu.
- **Chỉ số càng thấp càng tốt** (chi phí, hạn mức dùng) không phải mục tiêu mà là trần: theo thanh
  dung lượng (amber, đỏ khi gần đầy). Có nhịp kỳ vọng (ngân sách tháng) thì vạch nhịp như trên, đặt ở mức
  chi đều tới hôm nay; thanh vượt vạch là đang chi nhanh hơn nhịp.
- **Một hàng một kiểu phần dưới**: cả hàng là sparkline, hoặc cả hàng là thanh mục tiêu. Hàng trộn
  thì ô nào thiếu thì giữ chỗ cùng chiều cao như luật sparkline, nhưng nên tách ô mục tiêu ra một
  hàng hay một card riêng.
- **Chưa đặt mục tiêu**: ô về khuôn ô số thường, không thanh rỗng, không "0%".

Biểu đồ cột nhiều mốc ở màn hẹp thì cho cả cụm cuộn ngang **trong khung riêng**
bằng `overflow-x-auto` cộng một bề rộng tối thiểu cho cụm, đừng để nó đẩy cả
trang. Xem luật `R1` trong `../responsive.md`.

---

## Heatmap theo ngày ⚑

Số đếm theo từng ngày trong 12 tháng gần nhất: lượt hoạt động, buổi tập, ca trực, đơn mỗi ngày
(3/3 nguồn dùng đúng ca này). Cái cần đọc là **nhịp** (ngày nào dày, tuần nào trống), không phải từng
con số. Cần đọc số từng ngày, hay tiền theo ngày, thì là cột hoặc đường ("Cột hay đường").

```
1.284 lượt hoạt động trong 12 tháng qua
     Th12  Th1   Th2   Th3   ...                         Th11
T2   ▫ ▪ ▫ ■ ▪ ▫ ▫ ▪ ■ ▫ ...
     ▪ ▫ ■ ▪ ▫ ▪ ▫ ▫ ▪ ▪ ...
T4   ▫ ▪ ▫ ▫ ■ ▪ ▫ ▪ ▫ ■ ...
     ...                     (7 hàng: T2 → CN, mỗi cột một tuần, tuần cũ bên trái)
T6
                                              Ít ▫ ▪ ▪ ■ ■ Nhiều
```

- **Năm bậc: rỗng + bốn mức** (4/4 nguồn). Rỗng `bg-foreground/5`, bốn mức là `--primary` ở
  `/25`, `/50`, `/75` và đặc: màu nhấn có sắc (Cam, Xanh dương…) thì heatmap ra đúng sắc brand,
  không cần thang riêng; màu nhấn gần đen thì ra thang xám. Một sắc, đậm dần (`M3`); không cầu vồng, ngày nhiều cũng không đổi sang màu báo động (`M4`). Chia mốc
  bốn mức là logic người dùng (`N10`), thường theo phân vị của chính dữ liệu.
- **Lưới giãn hết bề ngang card**, khe `gap-1`, bo `rounded-xs`: `grid grid-flow-col auto-cols-fr
  grid-rows-[repeat(7,auto)] gap-1`, ô `aspect-square`. Khối lưới `min-w-[45rem]` (ô ~10px) để dưới mức
  đó thì cuộn ngang. Ô cố định `size-3` (53 cột ≈ 850px) thì card 1100px chừa một mảng trống bên phải,
  chú giải "Ít … Nhiều" lạc ra mép card cách lưới 400px (chủ dự án chê "lệch"). Nhãn tháng
  đặt theo phần trăm (`left: tuần / 53 × 100%`); cột nhãn T2/T4/T6 là một lưới `grid-rows-7 gap-1` cao
  bằng lưới ô (cột `flex flex-col pt-6`, lưới `flex-1`) để nhãn luôn thẳng hàng ô dù ô to nhỏ.
- **Hàng từ Thứ 2 tới Chủ nhật**, tuần theo lịch Việt Nam (`T28`). Nhãn ngày chỉ ghi **T2, T4, T6**
  `text-xs text-muted` bên trái (2/2 nguồn chỉ ghi cách một), các hàng khác vẫn có tên cho trình đọc
  màn hình. Nhãn tháng `Th1`…`Th12` trên đầu, ở cột chứa ngày đầu tháng.
- **Tiêu đề nói tổng**: "1.284 lượt hoạt động trong 12 tháng qua". **Chú giải "Ít ▫▪■ Nhiều"** góc dưới
  phải (2/2 nguồn), năm ô cùng cỡ ô lưới.
- **Rê hay Tab vào ô**: "3 lượt hoạt động ngày 09/11/2026", ngày rỗng "Không có hoạt động ngày
  03/11/2026": luôn kèm ngày, như "Nhãn trục bị thưa" ở biểu đồ đường. Bấm ô lọc danh sách bên dưới
  theo ngày đó (nếu màn có danh sách) là logic người dùng.
- **Ngày chưa tới** (phần còn lại của tuần này) không vẽ ô, không vẽ ô rỗng: ô rỗng nói "ngày đó không
  có gì".
- **Màn hẹp: cuộn ngang trong khung riêng** (2/2 nguồn), không thu nhỏ ô (`R1`). Khung cuộn sẵn tới
  mép phải lúc mở, để tuần gần nhất thấy ngay; nhãn T2/T4/T6 đứng ngoài vùng cuộn. **Gán `scrollLeft`
  sau khi khung có bề rộng thật** (`ResizeObserver` trên khối lưới, gán khi `scrollWidth > clientWidth`
  rồi ngắt): gán ngay sau khi render thì lúc đó lưới chưa có bề rộng, khung đứng yên ở tháng cũ nhất
  (bản dựng thử dính ở 375px).
- **Tiếp cận**: khung `role="img"` + `aria-label` tóm tắt ("1.284 lượt hoạt động trong 12 tháng, nhiều
  nhất tháng 10"); ô nhận focus thì mỗi ô `aria-label` đủ câu như khi rê. Màu bậc không phải tín hiệu duy
  nhất: số nằm trong câu.
- **Chưa có hoạt động nào**: không dựng 365 ô xám. Giữ chiều cao khung, một câu theo
  `empty-state.md` ("Chưa có hoạt động. Lịch sẽ dày dần từ buổi đầu tiên").

---

## Kiểm trước khi giao

Chạy cùng cổng 2 của `checklist.md` khi trang có đúng thứ này.

- [ ] **Biểu đồ đường** (`components/charts.md`): số ở điểm cuối có nằm đè lên đoạn nối không (điểm cuối thấp hơn điểm kề thì số phải xuống dưới chấm; probe báo "Nhãn số đè lên đường biểu đồ")? Điểm sát đáy (hôm nay mới vài giờ, số nhỏ): số có rơi xuống dưới đường 0, chen vào hàng nhãn trục ngay trên "27/09" không (probe báo "Nhãn số lòi ra ngoài vùng vẽ"; đặt sang cạnh chấm)? Rê vào một điểm giữa khi trục chỉ ghi vài nhãn: số có kèm ngày ("13/09 · 70,9 tr đ") không, hay chỉ còn con số không biết của ngày nào? Điểm chưa trọn kỳ có ghi "Hôm nay" không? Tab vào biểu đồ: số của mốc đang đứng có hiện ra không?
